﻿using System.Text;
using System.Text.Json;
using SolaceSystems.Solclient.Messaging;

namespace Communication.Api;

public sealed class SolacePublisher : IDisposable
{
    private readonly IContext _context;
    private readonly SolaceSystems.Solclient.Messaging.ISession _session;
    private readonly string _topic;



    public SolacePublisher(IConfiguration configuration)
    {
        var settings = configuration.GetSection("Solace");

        _topic = settings["Topic"]
            ?? throw new InvalidOperationException("Solace:Topic is missing.");

        ContextFactory.Instance.Init(new ContextFactoryProperties());

        _context = ContextFactory.Instance.CreateContext(
            new ContextProperties(), null);

        var properties = new SessionProperties
        {
            Host = settings["Host"],
            VPNName = settings["VpnName"],
            UserName = settings["Username"],
            Password = settings["Password"],
            SSLValidateCertificate = true,
            SSLTrustStoreDir = @"D:\solacePOC\certs"

        };

        _session = _context.CreateSession(properties, null, null);

        var result = _session.Connect();

        if (result != ReturnCode.SOLCLIENT_OK)
        {
            throw new InvalidOperationException(
                $"Could not connect to Solace: {result}");
        }
    }

    public void Publish(EmailRequest request)
    {
        var json = JsonSerializer.Serialize(request);

        using IMessage message = ContextFactory.Instance.CreateMessage();

        message.BinaryAttachment = Encoding.UTF8.GetBytes(json);
        message.Destination = ContextFactory.Instance.CreateTopic(_topic);
        message.DeliveryMode = MessageDeliveryMode.Persistent;

        var result = _session.Send(message);

        if (result != ReturnCode.SOLCLIENT_OK)
        {
            throw new InvalidOperationException(
                $"Solace publish failed: {result}");
        }
    }

    public void Dispose()
    {
        _session.Dispose();
        _context.Dispose();
    }
}