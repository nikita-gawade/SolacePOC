
using Communication.Api;

var builder = WebApplication.CreateBuilder(args);

// Register Solace publisher
builder.Services.AddSingleton<SolacePublisher>();

// Register Swagger services
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Enable Swagger
app.UseSwagger();
app.UseSwaggerUI();

// Email communication endpoint
app.MapPost("/api/communications/email",
    (EmailRequest request, SolacePublisher publisher) =>
    {
        if (string.IsNullOrWhiteSpace(request.RequestId) ||
            string.IsNullOrWhiteSpace(request.To))
        {
            return Results.BadRequest(
                new { error = "RequestId and To are required." });
        }

        try
        {
            publisher.Publish(request);

            return Results.Accepted(value: new
            {
                request.RequestId,
                status = "Published"
            });
        }
        catch (Exception ex)
        {
            app.Logger.LogError(
                ex, "Failed to publish email request");

            return Results.Problem(
                "Unable to submit communication request.",
                statusCode: StatusCodes.Status503ServiceUnavailable);
        }
    });

app.Run();
