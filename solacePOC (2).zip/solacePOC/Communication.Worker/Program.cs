using Communication.Worker;
using Communication.Worker.Data;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.AddHostedService<EmailConsumer>();
builder.Services.AddSingleton<EmailRequestRepository>();

var host = builder.Build();

using (var scope = host.Services.CreateScope())
{
    var repository = scope.ServiceProvider
    .GetRequiredService<EmailRequestRepository>();

    try
    {
        var connected = await repository.CanConnectAsync();

        Console.WriteLine(
            connected
                ? "SUCCESS: Connected to CommunicationDb!"
                : "FAILED: Could not verify CommunicationDb.");
    }
    catch (Exception ex)
    {
        Console.WriteLine($"DATABASE ERROR: {ex.Message}");
    }

}



await host.RunAsync();