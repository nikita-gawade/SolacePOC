﻿using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration;
using SolaceSystems.Solclient.Messaging;
using Communication.Worker.Data;
namespace Communication.Worker;

public sealed class EmailConsumer : BackgroundService
{
    private readonly IConfiguration _configuration;
    private readonly ILogger<EmailConsumer> _logger;
    private readonly EmailRequestRepository _repository;

    public EmailConsumer(
    IConfiguration configuration,
    ILogger<EmailConsumer> logger,
    EmailRequestRepository repository)
    {
        _configuration = configuration;
        _logger = logger;
        _repository = repository;
    }
    

    protected override async Task ExecuteAsync(
        CancellationToken stoppingToken)
    {
        var settings = _configuration.GetSection("Solace");
        IContext? context = null;
        ISession? session = null;
        IFlow? flow = null;

        try
        {

            var factoryProperties = new ContextFactoryProperties();
            factoryProperties.LogToConsoleError();

            ContextFactory.Instance.Init(factoryProperties);


            context = ContextFactory.Instance.CreateContext(
                new ContextProperties(), null);

            var sessionProperties = new SessionProperties
            {
                Host = settings["Host"],
                VPNName = settings["VpnName"],
                UserName = settings["Username"],
                Password = settings["Password"],
                SSLTrustStoreDir = @"D:\solacePOC\certs"
            };

            session = context.CreateSession(
                sessionProperties, null, null);


            try
            {
                var result = session.Connect();

                _logger.LogInformation(
                    "Solace connection result: {Result}", result);
            

                if (result != ReturnCode.SOLCLIENT_OK)
                throw new InvalidOperationException(
                    $"Solace connection failed: {result}");

            var queueName = settings["Queue"]
                ?? throw new InvalidOperationException(
                    "Solace:Queue is missing.");

            var queue = ContextFactory.Instance.CreateQueue(queueName);

            var flowProperties = new FlowProperties
            {
                AckMode = MessageAckMode.ClientAck
            };

            flow = session.CreateFlow(
                flowProperties,
                queue,
                null,
                async (sender, args) =>
                {
                    var message = args.Message;

                    try
                    {
                        var json = Encoding.UTF8.GetString(
                            message.BinaryAttachment);

                        var request = JsonSerializer.Deserialize<EmailRequest>(
                            json);

                        if (request is null)
                            throw new InvalidOperationException(
                                "Invalid email request.");

                        var alreadyExists = await _repository.ExistsAsync(
    request.RequestId,
    stoppingToken);

                        if (alreadyExists)
                        {
                            _logger.LogWarning(
                                "Duplicate request detected: {RequestId}",
                                request.RequestId);

                            var duplicateAck = flow!.Ack(message.ADMessageId);

                            if (duplicateAck != ReturnCode.SOLCLIENT_OK)
                            {
                                _logger.LogError(
                                    "Duplicate message acknowledgement failed: {Result}",
                                    duplicateAck);
                            }

                            return;
                        }

                        await _repository.InsertPendingAsync(
    request.RequestId,
    request.To,
    request.Subject,
    stoppingToken);
                        _logger.LogInformation(
                            "Received communication {RequestId} for {To}",
                            request.RequestId,
                            request.To);

                        // POC ONLY: simulate sending an email.
                        _logger.LogInformation(
                            "Simulated email sent. Subject: {Subject}; Letter: {LetterId}",
                            request.Subject,
                            request.LetterId ?? "(none)");

                        await _repository.UpdateStatusAsync(
    request.RequestId,
    "Completed",
    stoppingToken);

                        _logger.LogInformation(
                            "Email request marked Completed: {RequestId}",
                            request.RequestId);


                        var ackResult = flow!.Ack(message.ADMessageId);

                        if (ackResult != ReturnCode.SOLCLIENT_OK)
                        {
                            _logger.LogError(
                                "Message acknowledgement failed: {Result}",
                                ackResult);
                        }
                        else
                        {
                            _logger.LogInformation(
                                "Message acknowledged: {RequestId}",
                                request.RequestId);
                        }

                     
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError(
                            ex, "Message processing failed. Message was not acknowledged.");
                    }
                },
                (sender, args) =>
                {
                    _logger.LogInformation(
                        "Solace flow event: {Event}", args);
                });

            flow.Start();

            _logger.LogInformation(
                "Email consumer is listening on queue {Queue}", queueName);

            await Task.Delay(Timeout.Infinite, stoppingToken);
            }
            catch (OperationErrorException ex)
            {
                // Retrieve this immediately, before another Solace API call.
                var sdkError =
                    ContextFactory.Instance.GetLastSDKErrorInfo();

                _logger.LogError(
                    "Solace connection failed: {Exception}", ex.Message);

                _logger.LogError(
                    "Solace SDK details: {SdkError}", sdkError);

                throw;
            }

        }
        catch (OperationCanceledException)
            when (stoppingToken.IsCancellationRequested)
        {
            // Normal shutdown.
        }
        finally
        {
            flow?.Dispose();
            session?.Dispose();
            context?.Dispose();
        }
    }
}