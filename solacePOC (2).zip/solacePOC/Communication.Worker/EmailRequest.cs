﻿namespace Communication.Worker;

public sealed record EmailRequest(
    string RequestId,
    string To,
    string Subject,
    string Body,
    string? LetterId
);