﻿
using Microsoft.Data.SqlClient;

namespace Communication.Worker.Data;

public class EmailRequestRepository
{
    private readonly string _connectionString;

    public EmailRequestRepository(IConfiguration configuration)
    {
        _connectionString =
            configuration.GetConnectionString("CommunicationDb")
            ?? throw new InvalidOperationException(
                "CommunicationDb connection string is missing.");
    }

    public async Task<bool> CanConnectAsync(
        CancellationToken cancellationToken = default)
    {
        await using var connection =
            new SqlConnection(_connectionString);

        await connection.OpenAsync(cancellationToken);

        await using var command = new SqlCommand(
            "SELECT 1", connection);

        var result = await command.ExecuteScalarAsync(
            cancellationToken);

        return Convert.ToInt32(result) == 1;
    }
    public async Task<bool> InsertPendingAsync(
    string requestId,
    string recipient,
    string subject,
    CancellationToken cancellationToken = default)
    {
        const string sql = @"
        INSERT INTO EmailRequests
            (RequestId, Recipient, Subject, ProcessingStatus)
        VALUES
            (@RequestId, @Recipient, @Subject, @Status);";

        await using var connection =
            new SqlConnection(_connectionString);

        await connection.OpenAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);

        command.Parameters.AddWithValue("@RequestId", requestId);
        command.Parameters.AddWithValue("@Recipient", recipient);
        command.Parameters.AddWithValue("@Subject", subject);
        command.Parameters.AddWithValue("@Status", "Pending");

        var rows = await command.ExecuteNonQueryAsync(cancellationToken);

        return rows == 1;
    }
    public async Task UpdateStatusAsync(
    string requestId,
    string status,
    CancellationToken cancellationToken = default)
    {
        const string sql = @"
        UPDATE EmailRequests
        SET ProcessingStatus = @Status,
            ProcessedAtUtc = CASE
                WHEN @Status = 'Completed' THEN SYSUTCDATETIME()
                ELSE NULL
            END,
            LastError = NULL
        WHERE RequestId = @RequestId;";

        await using var connection =
            new SqlConnection(_connectionString);

        await connection.OpenAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);

        command.Parameters.AddWithValue("@RequestId", requestId);
        command.Parameters.AddWithValue("@Status", status);

        var rows = await command.ExecuteNonQueryAsync(cancellationToken);

        if (rows != 1)
        {
            throw new InvalidOperationException(
                $"Could not update request {requestId}. Rows affected: {rows}");
        }
    }
    public async Task<bool> ExistsAsync(
    string requestId,
    CancellationToken cancellationToken = default)
    {
        const string sql = @"
        SELECT CASE
            WHEN EXISTS (
                SELECT 1
                FROM EmailRequests
                WHERE RequestId = @RequestId
            )
            THEN 1
            ELSE 0
        END;";

        await using var connection =
            new SqlConnection(_connectionString);

        await connection.OpenAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);

        command.Parameters.AddWithValue("@RequestId", requestId);

        var result = await command.ExecuteScalarAsync(cancellationToken);

        return Convert.ToInt32(result) == 1;
    }
    public async Task MarkFailedAsync(
    string requestId,
    string error,
    CancellationToken cancellationToken = default)
    {
        const string sql = @"
        UPDATE EmailRequests
        SET ProcessingStatus = @Status,
            LastError = @LastError
        WHERE RequestId = @RequestId;";

        await using var connection =
            new SqlConnection(_connectionString);

        await connection.OpenAsync(cancellationToken);

        await using var command = new SqlCommand(sql, connection);

        command.Parameters.AddWithValue("@RequestId", requestId);
        command.Parameters.AddWithValue("@Status", "Failed");
        command.Parameters.AddWithValue(
            "@LastError",
            error.Length > 2000 ? error[..2000] : error);

        var rows = await command.ExecuteNonQueryAsync(cancellationToken);

        if (rows != 1)
        {
            throw new InvalidOperationException(
                $"Could not mark request {requestId} as Failed.");
        }
    }
}
