
import requests

API_URL = "https://localhost:5000/api/communications/email"

TOTAL_REQUESTS = 300
START_REQUEST_ID = 2001

for i in range(TOTAL_REQUESTS):
    request_id = f"COMM-{START_REQUEST_ID + i}"

    payload = {
        "requestId": request_id,
        "to": "test@example.com",
        "subject": "POC Letter",
        "body": "This is a test communication.",
        "letterId": "LETTER-50001"
    }

    try:
        response = requests.post(
            API_URL,
            json=payload,
            verify=False,  # For local development with a self-signed certificate
            timeout=30
        )

        print(
            f"{i + 1}/200 | "
            f"RequestId: {request_id} | "
            f"Status: {response.status_code} | "
            f"Response: {response.text}"
        )

    except requests.RequestException as e:
        print(f"{i + 1}/200 | RequestId: {request_id} | Error: {e}")

print("Completed sending all 200 requests.")
