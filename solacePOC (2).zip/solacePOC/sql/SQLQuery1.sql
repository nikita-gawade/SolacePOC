
CREATE DATABASE CommunicationDb;
GO

USE CommunicationDb;
GO

CREATE TABLE EmailRequests
(
    RequestId NVARCHAR(100) NOT NULL PRIMARY KEY,
    Recipient NVARCHAR(320) NOT NULL,
    Subject NVARCHAR(500) NOT NULL,
    ProcessingStatus NVARCHAR(30) NOT NULL
        DEFAULT 'Pending',
    CreatedAtUtc DATETIME2 NOT NULL
        DEFAULT SYSUTCDATETIME(),
    ProcessedAtUtc DATETIME2 NULL,
    LastError NVARCHAR(2000) NULL
);
GO

ALTER TABLE dbo.EmailRequests
ADD RetryCount INT NOT NULL
    CONSTRAINT DF_EmailRequests_RetryCount DEFAULT 0;
GO